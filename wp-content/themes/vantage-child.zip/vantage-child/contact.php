<?php /* Template Name: Contact */ ?>
<?php get_header(); ?>

<?php get_footer(); ?>